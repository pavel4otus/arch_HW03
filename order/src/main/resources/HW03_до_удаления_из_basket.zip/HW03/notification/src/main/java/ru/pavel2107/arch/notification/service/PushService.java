package ru.pavel2107.arch.notification.service;

public interface PushService {
    void push(String phone, String text);
}
