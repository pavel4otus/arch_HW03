package ru.pavel2107.arch.basket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.pavel2107.arch.basket.domain.Street;

public interface StreetRepo extends JpaRepository<Street, Long> {
}
