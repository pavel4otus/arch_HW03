package ru.pavel2107.arch.basket.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.pavel2107.arch.basket.domain.Address;

public interface AddressRepo extends JpaRepository<Address, Long> {
}
